# Analog Digital clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/Imran-hussain-the-bold/pen/PwYgMda](https://codepen.io/Imran-hussain-the-bold/pen/PwYgMda).

inspired from Black [ DD ] theme